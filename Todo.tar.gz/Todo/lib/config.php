<?php

	$dbhost = "localhost";
	$dbuser = "klopez_root";
	$dbpasswd = "linuxlinux";
	$dbname = "klopez_todo";

?>