<?php
	
	session_start();

	$email = $_SESSION['email'];
	//echo $email;

	include 'lib/config.php';
	require 'lib/bd.php';

	if (!empty($_POST['eliminar'])) { //Si fem clic sobre el botó esborrar entrarem a aquest if y pasarem el que 									ens interessa per poder realitzar l'operació
		$_SESSION['id'] = $_POST['id'];
		header('Location:borrar.php'); //Ens dirigim a borrar.php
		exit();
	}

	if (!empty($_POST['agregar'])) { //Si fem clic sobre el botó agregar entrarem en aquest if y pasarem el valor 									necessaris per realitzar l'operació
		$_SESSION['data'] = $_POST['data'];
		$_SESSION['completado'] = $_POST['completado'];
		$_SESSION['Tasca'] = $_POST['Tasca'];
		$_SESSION['email'] = $email;
		header('Location:agregar.php'); //Ens dirigim a agregar.php
		exit();
	}

	/*echo "Usuario correcto";
	echo $_SESSION['email'];*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Llistar</title>
	<link rel="stylesheet" type="text/css" href="public/css/bootstrap.min.css">
</head>
<body>
	<div class="container-fluid">
		<div class="text-right">	
			<form method="POST" action="logout.php">
			<input type="submit" name="logout" value="logout">
			</form>
		</div>
	</div>
	<div class="container-fluid">
	<div class="text-center">
		<?php //Ens connectarem a la base de dades per llistar totes les tarees d'aquest usuari
		$db = conecta($dbhost, $dbuser, $dbpasswd, $dbname);
		$sql = 'SELECT * FROM users INNER JOIN tasks ON users.id = tasks.users WHERE email="'.$_SESSION['email'].'" AND passwd="'.$_SESSION['password'].'";';
		//echo $sql;
		
		$result=$db->query($sql);

		if(!$result=$db->query($sql)) //si se ha producido de forma incorrecta
					{
						die("error en listar");
					}

		while($rec=$result->fetch_array())
					{
						if($rec['completado']==1){
							echo "<p><strike>".$rec['id'].".".$rec['descripcion']." --> ".$rec['completado']."</strike><p>";
						}
						else
							echo "<p>".$rec['id'].".".$rec['descripcion']." --> ".$rec['completado']."<p>";
						
					}
	


			$db->close();
	?>
	</div>
	<div class="text-center">
		<form method="POST" action="<?= $_SERVER['PHP_SELF'];?>">
			<label>Eliminamos? </label><input type="text" name="id" placeholder='"numero de id"'>
			<input type="submit" name="eliminar" value="Eliminar" class="btn"><br>
				<label>Data: </label><input type="text" name="data" placeholder='"2016/11/12"'>
				<label>Completado? </label><input type="text" name="completado" placeholder='"0/1"'>
				<label>Tasca: </label><input type="text" name="Tasca" placeholder='"Tasca"'>
			<input type="submit" name="agregar" value="Agregar" class="btn">
		</form>
	</div>
	</div>
</body>
</html>