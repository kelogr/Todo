<?php
	ini_set('display_errors', '1');
	include 'lib/config.php';
	require 'lib/bd.php';
?>