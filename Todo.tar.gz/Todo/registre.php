<?php

	include 'lib/config.php';
	require 'lib/bd.php';

				if(!empty($_POST['email']) && !empty($_POST['passwd'])) //!empty= NO ESTA VACIO 
				{

					$email = $_POST['email'];
					
					$password = $_POST['passwd'];

					$db = conecta($dbhost, $dbuser, $dbpasswd, $dbname);

					$sql2 = 'SELECT count(email) FROM users WHERE email = "'.$email.'";';

					if ($result1 = mysqli_query($db, $sql2)) 
					{
						if ($row1 = mysqli_fetch_array($result1)) 
						{
							if ($row1['count(email)']==1)
							{
								echo "Aquest usuari ja existeix.";
							}else
							{
								$sql="INSERT INTO users(email,passwd) VALUES('".$_POST['email']."','".$_POST['passwd']."')";
								if($result=$db->query($sql)) 
								{
										header('Location:login.php');
										exit();
								}else
								{
									header('Location:registre.php');
										exit();
								}
							}

						}else
						{
							header('Location:login.php');
							exit();
						}
					}
					else
					{
						header('Location:registre.php');
						exit();
					}
					$db->close();
				}	
				
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Registre</title>
	<link rel="stylesheet" type="text/css" href="public/css/bootstrap.min.css">
</head>
<body>
	<div class="container-fluid">
		<div class="text-right">	
			<form method="POST" action="logout.php">
			<input type="submit" name="logout" value="Volver" class="btn">
			</form>
		</div>
	<div class="container-fluid">
		<div class="jumbotron">
			<h1>Registre</h1>
		</div>
		<div class="text-center">
			<form method="POST" action="<?= $_SERVER['PHP_SELF'];?>">

			<p>Email:<input type="text" name="email"></p>
			<p>Contrasenya:<input type="password" name="passwd"></p>
			<p><input type="submit" name="Inserta"></p>

			</form>
		</div>
	</div>
</body>
</html>