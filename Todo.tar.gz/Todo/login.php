<?php
	
	session_start(); //Iniciem sessió al servidor

	//Per errors amb l'index.php he decidit realitzar-ho aquí.
	include 'lib/config.php'; //Aquest arxiu inclou tota la configuració necessaria pero poder establir connexió amb la base de dades que es connectará des de la llibreria bd.php
	require 'lib/bd.php';

		if(!empty($_POST)) //si POST no es buit
			{
				if(!empty($_POST['user']) && !empty($_POST['passwd'])) //!empty= NO ESTA VACIO 
				{
					$email = $_POST['user']; //Guardem les variables de POST a altra variable pero no treballar amb elles directament
					
					$password = $_POST['passwd'];

					$db = conecta($dbhost, $dbuser, $dbpasswd, $dbname); //cridem a la funció conecta de bd.php 
					
					$sql = 'SELECT * FROM users WHERE email="'.$email.'" AND passwd="'.$password.'" LIMIT 1;';
					//Guardem la consulta que realitzarem. Buscarem els usuaris que es trobin dins de la base de dades.
	
					if ($result = mysqli_query($db, $sql)) { //En el cas que es trobi algun resultat continuarem, sino tornará a carregar la mateixa pagina per que no ha trobat el usuari o que ens hem equivocat de contraseña
						if ($row = mysqli_fetch_array($result)) {
							$_SESSION['email'] = $email; //Guardem les variables que hem utilitzat a una de sessió per poder utilitzarles si les necessitem més en devant a altra pagina
							$_SESSION['password'] = $password;
							//Creem les cookies a questa pagina
							setcookie('email', $email, time()+1800, '/todo', ''); //(nom, valor, temps expiració, lloc)
							setcookie('password', $password, time()+1800, '/todo', '');
							//redireccionarem la pagina a list.php sortint de la que ens trobem
							header('Location:list.php');
							exit();
						}
						else{
						header('Location:login.php');
						exit();
						}
						}
					else{
						header('Location:login.php');
						exit();
					}
					
				}
			}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="public/css/bootstrap.min.css">
</head>
<body>
	<div class="container-fluid">
		<div class="text-right">	
			<form method="POST" action="registre.php">
					<input type="submit" name="enviar" value="Registrar-se" class="btn">
			</form>
		</div>
	</div>
	<div class="container-fluid">
		<div class="jumbotron">
			<h1 class="h1">LOGIN</h1>
		</div>	
	</div>
	<div class="container-fluid">
		<div class="text-center">
			<form method="POST" action="<?= $_SERVER['PHP_SELF'];?>">
				<label>User: </label><input type="text" name="user"  class="input-sm"><?=$_COOKIE['email']?><br>
				<label>Password: </label><input type="password" name="passwd"  class="input-sm"><?=$_COOKIE['password']?><br>
				<input type="submit" name="enviar" value="Enviar" class="btn">
			</form>
		</div>	
	</div>
</body>
</html>
