<?php 
	session_start();

	include 'lib/config.php';
	require 'lib/bd.php';

	$data = $_SESSION['data'];
	$completado = $_SESSION['completado'];
	$tasca = $_SESSION['Tasca'];


	if (!empty($tasca)) {

		$db = conecta($dbhost, $dbuser, $dbpasswd, $dbname);

		$sql = 'SELECT users.id FROM users INNER JOIN tasks ON users.id = tasks.users WHERE email = "'.$_SESSION['email'].'" LIMIT 1;'; //Obtenim del usuari al que anem a agregar, es a dir, amb qui hem accedit i anem a agregar
		
		if ($result = mysqli_query($db, $sql)) {
			if ($row = mysqli_fetch_array($result)) {
					
					$sql1 ='INSERT INTO tasks(data, completado, descripcion, users) VALUES("'.$data.'","'.$completado.'","'.$tasca.'","'. $row['id'].'");'; //Insertem els valor dins de la taula
					
					if($result1=$db->query($sql1)) 
						{
							header('Location:list.php');
							exit();
						}
					else
						{
							die("error en borrar");
						}
				//echo 1;
				}
				else{
					echo -3; //Missatge de error en cas de no obtenir cap valor
				}
			}
			else
			{
				echo -1; //Error en cas de que no funcioni la conexió o la sentencia o ambes
			}
	}
	else
	{
		echo -2; //Error en cas de no pasar correctament les dades
	}

 ?>